### Care Connect API Search Parameters

{% include table-searchparameters.xhtml %}