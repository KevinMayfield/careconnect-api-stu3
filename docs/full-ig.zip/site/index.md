
The purpose of this IG is to demonstrate documenting an endpoint/server using FHIR ImplementationGuide.

It is not representing a conformance statandard.